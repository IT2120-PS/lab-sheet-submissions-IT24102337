setwd("C:/Users/User/Desktop/IT24102337 pslab03")
getwd()
# 1. Import the dataset
student_data <- read.csv("Exercise.csv")
# View first few rows to check
head(student_data)
# 2. Summary statistics and histogram for X1 (Age)
summary(student_data$X1)
hist(student_data$X1,
     main = "Histogram of Age (X1)",
     xlab = "Age",
     col = "skyblue",
     border = "black")
# 3. Bar chart and frequency table for X2 (Gender)
table(student_data$X2)
barplot(table(student_data$X2),
        main = "Gender Distribution (X2)",
        xlab = "Gender",
        ylab = "Frequency",
        col = c("pink", "lightblue"))
# 4. Age (X1) change according to accommodation (X3)
boxplot(X1 ~ X3, data = student_data,
        main = "Age vs Accommodation Type",
        xlab = "Accommodation Type (X3)",
        ylab = "Age",
        col = c("lightgreen", "orange", "lightblue"))
