setwd("C:/Users/User/Desktop/IT24102337 pslab2")
set.seed(123)
getwd()
print(sample(1:3))
print(sample(1:3, size = 3, replace = FALSE))
print(sample(c(2,5,3), size = 4, replace = TRUE))
print(sample(1:2, size = 10, prob = c(0.3, 0.7), replace = TRUE))

sample(1:3)
sample(1:3, size = 3, replace = FALSE)
sample(c(2,5,3), size = 4, replace = TRUE)
sample(c(2,5,3), size = 4, replace = FALSE)
sample(1:2, size = 10, prob = c(0.3, 0.7), replace = TRUE)

x <- 7
if (x > 10) {
  print("x is greater than 10")
} else if (x == 10) {
  print("x equals 10")
} else {
  print("x is less than 10")
}

vec <- c(1, 3, 5)
for (i in 1:length(vec)) {
  print(vec[i])
}

# While loop
i <- 1
while (i <= length(vec)) {
  print(vec[i])
  i <- i + 1
}

# Functions
addnums <- function(a, b = 5) {
  result <- a + b
  return(result)
}
addnums(10)
addnums(10, 20)


# Importing and Exporting
Data1 <- read.table("Data1.txt", header = TRUE, sep = ",")
DATA2 <- read.csv("DATA 2.csv", header = TRUE)

print(Data1)
print(DATA2)

# Create Sheep data frame
Height <- c(90, 95, 88, 102, 110)
Weight <- c(15.2, 16.1, 14.9, 17.3, 18.0)
Sheep <- data.frame(Height, Weight)
print(Sheep)

# Export Sheep
write.csv(Sheep, "Sheep.csv", row.names = FALSE)
write.table(Sheep, "Sheep.txt", row.names = FALSE, quote = FALSE)


# Q1
x <- c(1, 2, 3)
Q1_result <- x[1] / x[2]^3 - 1 + 2 * x[3] - x[2 - 1]
Q1_result  

# Q2
sum((1:15) %% 3 == 0)  

# Q3
v <- c(5, 9, 3, 7, 9)
max_index <- 1
for (i in 2:length(v)) {
  if (v[i] > v[max_index]) {
    max_index <- i
  }
}
max_index

# Q4
which.max(v)
